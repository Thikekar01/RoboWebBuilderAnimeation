const msg = document.getElementById('msg');
document.getElementById('yes').addEventListener('click', async () => {
  const c = await loadCfg(); c.consent = true; await saveCfg(c);
  msg.textContent = 'Enabled! Open any website to see it. Use the toolbar icon to pause or exclude sites.';
});
document.getElementById('no').addEventListener('click', () => {
  msg.textContent = 'No problem. You can enable it any time from the toolbar icon (Replay animation) or by reopening this page.';
});
