# 🤖 RoboBuilder (v0.2)

A swarm of robots flies in and rebuilds every page you open, tile by tile, then flies away. Free, offline, no server, no analytics. No widgets, chatbox or contents panel.

## Install (no build step)
1. Open `chrome://extensions`, turn on **Developer mode**.
2. **Load unpacked** and choose this folder (the one with `manifest.json`).
3. On the welcome page click **Enable automatic mode**, then open any website.

## Behavior
Skip button, Esc / click / scroll to skip, 10 s fail-safe, `prefers-reduced-motion` respected, once-per-day by default, per-site pause/exclude in the toolbar popup. Banking, login, checkout, mail, password-manager, Web Store and PDF pages are never touched.

License: MIT
