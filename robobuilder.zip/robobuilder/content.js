// RoboBuilder content script (plain JS, no build step). MIT licensed.
// A swarm of robots rebuilds the page tile by tile, then flies away. No widgets, no network.
(() => {
'use strict';
if (window.top !== window || window.__robobuilder) return;
window.__robobuilder = true;

const HOST = location.hostname, DAY = 864e5;
const DEFAULTS = { consent: false, mode: 'daily', speed: 1, excluded: [], paused: [], seen: {}, forceReplay: '' };
const S = { cfg: null, aborted: false, host: null, waiters: [], timer: null, listeners: [] };

const el = (tag, cls, txt) => { const e = document.createElement(tag); if (cls) e.className = cls; if (txt != null) e.textContent = txt; return e; };
const sleepRaw = ms => new Promise(r => setTimeout(r, ms));
const T = ms => ms / ((S.cfg && S.cfg.speed) || 1);
const wait = ms => new Promise(r => { const t = setTimeout(r, T(ms)); S.waiters.push(() => { clearTimeout(t); r(); }); });
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const rnd = (a, b) => a + Math.random() * (b - a);

// ---------- settings ----------
const loadCfg = () => new Promise(r => {
  try { chrome.storage.local.get('cfg', d => r({ ...DEFAULTS, ...(d.cfg || {}) })); } catch (e) { r({ ...DEFAULTS }); }
});
const markSeen = () => { try { chrome.storage.local.get('cfg', d => { const c = d.cfg || {}; c.seen = { ...(c.seen || {}), [HOST]: Date.now() }; if (c.forceReplay === HOST) c.forceReplay = ''; chrome.storage.local.set({ cfg: c }); }); } catch (e) {} };

// ---------- sensitive pages (never run) ----------
function isSensitive() {
  const h = HOST.toLowerCase(), p = location.pathname.toLowerCase();
  if (/paypal|stripe\.com|bank|netbanking|hdfc|icici|axisbank|chase\.com|wellsfargo|1password|bitwarden|lastpass|dashlane|mychart|patient/.test(h)) return true;
  if (/^(mail\.google\.com|outlook\.live\.com|outlook\.office\.com|mail\.yahoo\.com|mail\.proton\.me|accounts\.google\.com|login\.microsoftonline\.com|chromewebstore\.google\.com)$/.test(h)) return true;
  if (h === 'chrome.google.com' && p.startsWith('/webstore')) return true;
  if (/\/(log-?in|sign-?in|signup|sign-up|checkout|payment|billing|password|auth)(\/|$|\.)/.test(p)) return true;
  if (/\.pdf$/.test(p) || document.contentType === 'application/pdf') return true;
  return false;
}

// ---------- robots ----------
const COLORS = ['#3b82f6', '#facc15', '#f97316', '#a855f7'];
const robotSVG = c => `<svg viewBox="0 0 80 80" width="44" height="44"><path d="M40 6v8" stroke="#555" stroke-width="3"/><circle cx="40" cy="5" r="4" fill="${c}"/><rect x="18" y="14" width="44" height="32" rx="10" fill="${c}" stroke="#222" stroke-width="3"/><circle cx="31" cy="30" r="5" fill="#fff"/><circle cx="49" cy="30" r="5" fill="#fff"/><circle cx="31" cy="30" r="2.2" fill="#111"/><circle cx="49" cy="30" r="2.2" fill="#111"/><rect x="24" y="48" width="32" height="22" rx="6" fill="${c}" stroke="#222" stroke-width="3"/><rect x="10" y="50" width="10" height="5" rx="2.5" fill="#222"/><rect x="60" y="50" width="10" height="5" rx="2.5" fill="#222"/></svg>`;
function makeRobot(x, y, color) {
  const e = el('div', 'rb'); e.innerHTML = robotSVG(color) + '<div class="carry"></div><div class="sb"></div>';
  e.style.transform = `translate(${x}px,${y}px)`; S.rl.appendChild(e);
  const bot = { el: e, x, y,
    state(s) { e.dataset.state = s; },
    say(t) { e.querySelector('.sb').textContent = S.aborted ? '' : t; },
    async go(nx, ny, ms) {
      if (S.aborted) return;
      const a = e.animate([{ transform: `translate(${bot.x}px,${bot.y}px)` }, { transform: `translate(${nx}px,${ny}px)` }], { duration: T(ms), easing: 'cubic-bezier(.4,0,.2,1)', fill: 'forwards' });
      try { await a.finished; } catch (err) {}
      bot.x = nx; bot.y = ny; e.style.transform = `translate(${nx}px,${ny}px)`; try { a.cancel(); } catch (err) {}
    } };
  return bot;
}

const COVER_CSS = `:host{all:initial}.cv,.wf,.rl{position:fixed;inset:0;pointer-events:none;overflow:hidden}
.tile{position:fixed;background:#fff;box-shadow:inset 0 0 0 1px #e2e8f0}
.frame{position:fixed;inset:6px;border:2px solid #cbd5e1;border-radius:10px}.url{position:fixed;top:12px;left:50%;transform:translateX(-50%);background:#f1f5f9;border-radius:99px;padding:3px 14px;font:12px system-ui;color:#475569}
.laser{position:fixed;left:0;top:0;width:100%;height:3px;background:linear-gradient(90deg,transparent,#3b82f6,transparent);box-shadow:0 0 12px #3b82f6}
.rb{position:fixed;left:0;top:0;width:44px;height:44px}.rb svg{display:block;animation:bob .8s ease-in-out infinite alternate}
.rb[data-state=celebrating] svg{animation:hop .35s ease-in-out infinite alternate}
.carry{display:none;position:absolute;left:8px;top:-16px;width:28px;height:16px;background:#fb923c;border:2px solid #222;border-radius:3px;box-shadow:0 0 12px #fb923c}.rb.carrying .carry{display:block}
.sb{display:none;position:absolute;bottom:48px;left:50%;transform:translateX(-50%);background:#fff;color:#111;border:2px solid #222;border-radius:10px;padding:3px 8px;font:12px system-ui;white-space:nowrap}.sb:not(:empty){display:block}
.dust{position:fixed;width:10px;height:10px;border-radius:50%;background:#94a3b8}
.skip{position:fixed;top:14px;right:14px;z-index:5;border:0;border-radius:99px;background:#111;color:#fff;padding:7px 14px;font:600 13px system-ui;cursor:pointer;opacity:.9}
@keyframes bob{to{transform:translateY(-3px)}}@keyframes hop{to{transform:translateY(-8px) rotate(6deg)}}`;

// ---------- cover (injected at document_start so the real page never flashes) ----------
function startCover() {
  const h = el('div'); h.id = 'rb-host'; h.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none';
  const root = h.attachShadow({ mode: 'open' }), st = el('style'); st.textContent = COVER_CSS;
  const art = el('div'); art.setAttribute('aria-hidden', 'true');   // decorative: hidden from screen readers, never blocks input
  S.cv = el('div', 'cv'); S.wf = el('div', 'wf'); S.rl = el('div', 'rl'); art.append(S.cv, S.wf, S.rl);
  const skip = el('button', 'skip', 'Skip ✕'); skip.setAttribute('aria-label', 'Skip RoboBuilder animation'); skip.style.pointerEvents = 'auto'; skip.addEventListener('click', skipAnim);
  root.append(st, art, skip); document.documentElement.appendChild(h); S.host = h;
  // one full-viewport white tile until the grid is built, so nothing flashes
  S.first = el('div', 'tile'); S.first.style.cssText = 'inset:0'; S.cv.appendChild(S.first);
  const on = (t, f) => { addEventListener(t, f, true); S.listeners.push([t, f]); };
  on('keydown', e => { if (e.key === 'Escape') skipAnim(); }); ['mousedown', 'wheel', 'touchstart'].forEach(t => on(t, skipAnim));
  S.timer = setTimeout(skipAnim, 10000);   // fail-safe: cover is always gone after 10s
}
function removeCover() {
  clearTimeout(S.timer); S.listeners.forEach(([t, f]) => removeEventListener(t, f, true)); S.listeners = [];
  if (S.host) { S.host.remove(); S.host = null; }
}
function skipAnim() { S.aborted = true; S.waiters.splice(0).forEach(f => f()); removeCover(); }

const dust = (x, y) => { for (let i = 0; i < 4; i++) { const d = el('div', 'dust'); d.style.left = x + 'px'; d.style.top = y + 'px'; S.rl.appendChild(d);
  d.animate([{ transform: 'translate(0,0) scale(.4)', opacity: .8 }, { transform: `translate(${(i - 1.5) * 16}px,-12px) scale(1.4)`, opacity: 0 }], { duration: T(450), fill: 'forwards' }).finished.then(() => d.remove(), () => d.remove()); } };

// ---------- the swarm rebuild ----------
async function playBuild() {
  const W = innerWidth, H = innerHeight;
  // blueprint grid made of white tiles over the real page
  const cell = Math.max(90, Math.sqrt(W * H / 110)), cols = Math.ceil(W / cell), rows = Math.ceil(H / cell), cw = W / cols, ch = H / rows;
  const tiles = [];
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
    const t = el('div', 'tile'); Object.assign(t.style, { left: c * cw + 'px', top: r * ch + 'px', width: cw + 1 + 'px', height: ch + 1 + 'px' });
    S.cv.appendChild(t); tiles.push({ t, cx: c * cw + cw / 2, cy: r * ch + ch / 2, key: r + Math.random() * 1.8 });
  }
  S.first.remove();
  S.wf.append(el('div', 'frame'), el('div', 'url', '🔒 ' + HOST));
  const queue = tiles.sort((a, b) => a.key - b.key);   // rough top-to-bottom wave

  // swarm flies in from all four edges
  const N = clamp(Math.round(W / 70), 10, 20);
  const bots = Array.from({ length: N }, (_, i) => {
    const side = i % 4, sx = side === 0 ? -60 : side === 1 ? W + 20 : rnd(0, W), sy = side === 2 ? -60 : side === 3 ? H + 20 : rnd(0, H);
    return makeRobot(sx, sy, COLORS[i % 4]);
  });
  await Promise.all(bots.map(b => b.go(rnd(30, W - 80), rnd(60, H - 100), rnd(600, 900))));
  if (S.aborted) return;

  // brief laser scan
  bots[0].say('Scanning page…');
  const laser = el('div', 'laser'); S.wf.appendChild(laser);
  try { await laser.animate([{ transform: 'translateY(0)' }, { transform: `translateY(${H}px)` }], { duration: T(700), easing: 'linear', fill: 'forwards' }).finished; } catch (e) {}
  laser.remove(); bots[0].say('Rebuilding!'); if (S.aborted) return;

  // every robot repeatedly grabs a block, carries it to the next free tile, drops it, and the tile becomes the real page
  const work = async b => {
    while (queue.length && !S.aborted) {
      const tl = queue.shift(), tx = clamp(tl.cx - 22, 0, W - 44), ty = clamp(tl.cy - 56, 0, H - 44);
      b.el.classList.add('carrying');
      await b.go(tx, ty, rnd(320, 560)); if (S.aborted) return;
      b.el.classList.remove('carrying');
      try { b.el.animate([{ transform: `translate(${tx}px,${ty}px)` }, { transform: `translate(${tx}px,${ty + 10}px)` }, { transform: `translate(${tx}px,${ty}px)` }], { duration: T(180) }); } catch (e) {}
      dust(tl.cx, tl.cy);
      tl.t.animate([{ background: '#fff', opacity: 1 }, { background: '#bfdbfe', opacity: 1, offset: .3 }, { background: '#bfdbfe', opacity: 0 }], { duration: T(360), fill: 'forwards' }).finished.then(() => tl.t.remove(), () => {});
    }
  };
  await Promise.all(bots.map(work));
  if (S.aborted) return;
  await wait(380);

  // celebrate and fly away
  bots.forEach(b => b.state('celebrating')); bots[0].say('Done! 👋'); await wait(500); if (S.aborted) return;
  await Promise.all(bots.map(b => { const left = b.x < W / 2; return b.go(left ? -80 : W + 40, b.y - rnd(0, 120), rnd(450, 700)); }));
}

// ---------- messages / settings changes ----------
try {
  chrome.runtime.onMessage.addListener((m, _s, res) => { if (m.type === 'skip') skipAnim(); res && res({ ok: true }); });
  chrome.storage.onChanged.addListener(c => { const v = c.cfg && c.cfg.newValue; if (v && ((v.excluded || []).includes(HOST) || (v.paused || []).includes(HOST))) skipAnim(); });
} catch (e) {}

// ---------- bootstrap ----------
const domReady = () => new Promise(r => { if (document.readyState !== 'loading') return r(); const t = setTimeout(r, 4000); document.addEventListener('DOMContentLoaded', () => { clearTimeout(t); r(); }, { once: true }); });
(async () => {
  try {
    if (isSensitive()) return;
    S.cfg = await loadCfg(); const c = S.cfg;
    if (!c.consent || c.excluded.includes(HOST) || c.paused.includes(HOST)) return;
    const seen = c.seen[HOST], reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const full = c.forceReplay === HOST || c.mode === 'always' || (c.mode === 'site' && !seen) || (c.mode === 'daily' && (!seen || Date.now() - seen > DAY));
    if (!full || c.mode === 'never' && c.forceReplay !== HOST || reduced) return;
    startCover();
    await domReady(); await sleepRaw(80);
    if (document.querySelector('input[type=password]') || isSensitive()) { skipAnim(); return; }   // login-like page: show nothing
    if (!S.aborted) await playBuild();
    removeCover(); markSeen();
  } catch (e) { console.warn('[RoboBuilder]', e); removeCover(); }
})();
})();
