const DEFAULTS = { consent: false, mode: 'daily', speed: 1, excluded: [], paused: [], seen: {}, forceReplay: '',
  widgets: { chat: true, top: true, progress: true, toc: true, tldr: true, read: true, dark: true } };
const loadCfg = () => new Promise(r => chrome.storage.local.get('cfg', d => { const c = d.cfg || {}; r({ ...DEFAULTS, ...c, widgets: { ...DEFAULTS.widgets, ...(c.widgets || {}) } }); }));
const saveCfg = c => new Promise(r => chrome.storage.local.set({ cfg: c }, r));
