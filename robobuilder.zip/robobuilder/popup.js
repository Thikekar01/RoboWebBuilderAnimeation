(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let host = ''; try { host = new URL(tab.url).hostname; } catch (e) {}
  document.getElementById('host').textContent = host || 'This page cannot be used with RoboBuilder';
  const cfg = await loadCfg(), $ = id => document.getElementById(id);
  const has = k => cfg[k].includes(host);
  $('paused').checked = has('paused'); $('excluded').checked = has('excluded'); $('mode').value = cfg.mode; $('speed').value = String(cfg.speed);
  const toggle = (k, on) => { cfg[k] = cfg[k].filter(h => h !== host); if (on && host) cfg[k].push(host); return saveCfg(cfg); };
  $('paused').onchange = e => toggle('paused', e.target.checked); $('excluded').onchange = e => toggle('excluded', e.target.checked);
  $('mode').onchange = e => { cfg.mode = e.target.value; saveCfg(cfg); }; $('speed').onchange = e => { cfg.speed = +e.target.value; saveCfg(cfg); };
  const send = type => { try { chrome.tabs.sendMessage(tab.id, { type }, () => void chrome.runtime.lastError); } catch (e) {} };
  $('skip').onclick = () => send('skip');
  $('replay').onclick = async () => { cfg.forceReplay = host; cfg.consent = true; await saveCfg(cfg); chrome.tabs.reload(tab.id); window.close(); };
})();
